package com.sq.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.*;


public class MainActivity extends AppCompatActivity {

    ArrayList<String> items;
    ArrayAdapter<String> itemsAdapter;
    ListView lvItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取列表的属性ID
        lvItems = (ListView) findViewById(R.id.lvItems);

        items = new ArrayList<String>();

        readItems();
        setupListViewListener();
        itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,items);
        lvItems.setAdapter(itemsAdapter);

      /*  String content = "I'm a " + " big.com";
        String pattern = ".*big.*";

        boolean isMatch = Pattern.matches(pattern,content);
        System.out.println(content + "    " +isMatch + "\\\\" + "0202"+"\\("+"0202"+"\n"+"");*/
    }

    //在每次运行时都读取文档内容
    private void readItems(){
        File filesDir = getFilesDir();
        File todoFile = new File(filesDir,"todo.txt");
        try{
            items = new ArrayList<String>(FileUtils.readLines(todoFile,"UTF-8"));
        }catch(IOException e){
            items = new ArrayList<String>();
            e.printStackTrace();
        }
    }

    //长按点击事件，长按可以删除该长按内容的内容
    private void setupListViewListener(){
        lvItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                items.remove(position);
                itemsAdapter.notifyDataSetChanged();
                saveItems();
                return true;
            }
        });
    }

    //保存每次输入的文件的内容
    private void saveItems(){
        File filesDir = getFilesDir();
        File todoFile = new File(filesDir,"todo.txt");
        try{
           FileUtils.writeLines(todoFile,items);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    //button的点击事件，每次按下按钮可以增加备忘录的内容
    public void addTodoItem(View v){
        EditText etNewItem = (EditText)findViewById(R.id.edNewItem);
        itemsAdapter.add(etNewItem.getText().toString());
        etNewItem.setText("");
        saveItems();
    }
}